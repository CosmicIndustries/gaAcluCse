
from fastapi import FastAPI, Request
import httpx

app = FastAPI()

AGENTS = {
    "bot_a": "http://bot_a:5005/webhooks/rest/webhook",
    "bot_b": "http://bot_b:5005/webhooks/rest/webhook"
}

@app.post("/webhook/{bot_id}")
async def message_router(bot_id: str, request: Request):
    if bot_id not in AGENTS:
        return {"error": "Bot not found"}

    data = await request.json()
    async with httpx.AsyncClient() as client:
        response = await client.post(AGENTS[bot_id], json=data)
        return response.json()
